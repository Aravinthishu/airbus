'use client';
import React from 'react';
import { ComponentId } from '../types';
import { ButtonDemo, ButtonSpec } from './button';
import { ButtonGroupDemo, ButtonGroupSpec } from './button-group';
import { FabDemo, FabSpec } from './fab';
import { InputFieldDemo, InputFieldSpec } from './input-field';
import { TextAreaDemo, TextAreaSpec } from './text-area';
import { CheckboxDemo, CheckboxSpec } from './checkbox';
import { DatePickerDemo, DatePickerSpec } from './date-picker';

export function LiveDemo({ id }: { id: ComponentId }) {
  switch (id) {
    case 'button': return <ButtonDemo />;
    case 'buttongroup': return <ButtonGroupDemo />;
    case 'fab': return <FabDemo />;
    case 'inputfield': return <InputFieldDemo />;
    case 'textarea': return <TextAreaDemo />;
    case 'checkbox': return <CheckboxDemo />;
    case 'datepicker': return <DatePickerDemo />;
    default: return null;
  }
}

export function SpecSheet({ id }: { id: ComponentId }) {
  switch (id) {
    case 'button': return <ButtonSpec />;
    case 'buttongroup': return <ButtonGroupSpec />;
    case 'fab': return <FabSpec />;
    case 'inputfield': return <InputFieldSpec />;
    case 'textarea': return <TextAreaSpec />;
    case 'checkbox': return <CheckboxSpec />;
    case 'datepicker': return <DatePickerSpec />;
    default: return null;
  }
}
