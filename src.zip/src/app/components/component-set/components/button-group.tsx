'use client';
import React, { useState } from 'react';
import Image from 'next/image';
import { PropChip, SpecBadge, SpecBlock } from '../ui-helpers';

/* ============================================================
   BUTTON GROUP IMAGES — correct these paths/filenames to match
   whatever actually lives in your assets/images/button-group folder.
   Names below are derived from your Figma layer labels:
     "Size=L, Item n.=3"
     "Status=Active/Default/Disabled/Focus (depreciated)/Hover, Side=Left/Center/Right"
============================================================ */
import btnGroupBase from '../../../../assets/images/button-group/btn-group-size-l-3.png';

import btnGroupDefaultLeft from '../../../../assets/images/button-group/btn-group-default-left.png';
import btnGroupDefaultCenter from '../../../../assets/images/button-group/btn-group-default-center.png';
import btnGroupDefaultRight from '../../../../assets/images/button-group/btn-group-default-right.png';

import btnGroupHoverLeft from '../../../../assets/images/button-group/btn-group-hover-left.png';
import btnGroupHoverCenter from '../../../../assets/images/button-group/btn-group-hover-center.png';
import btnGroupHoverRight from '../../../../assets/images/button-group/btn-group-hover-right.png';

import btnGroupActiveLeft from '../../../../assets/images/button-group/btn-group-active-left.png';
import btnGroupActiveCenter from '../../../../assets/images/button-group/btn-group-active-center.png';
import btnGroupActiveRight from '../../../../assets/images/button-group/btn-group-active-right.png';

import btnGroupFocusLeft from '../../../../assets/images/button-group/btn-group-focus-left.png';
import btnGroupFocusCenter from '../../../../assets/images/button-group/btn-group-focus-center.png';
import btnGroupFocusRight from '../../../../assets/images/button-group/btn-group-focus-right.png';

import btnGroupDisabledLeft from '../../../../assets/images/button-group/btn-group-disabled-left.png';
import btnGroupDisabledCenter from '../../../../assets/images/button-group/btn-group-disabled-center.png';
import btnGroupDisabledRight from '../../../../assets/images/button-group/btn-group-disabled-right.png';

// Import the individual images for preview
import btnGroup1 from '../../../../assets/images/button-group/btn-group-1.png';
import btnGroup2 from '../../../../assets/images/button-group/btn-group-2.png';
import btnGroup3 from '../../../../assets/images/button-group/btn-group-3.png';
import btnGroup4 from '../../../../assets/images/button-group/btn-group-4.png';

// Import the combined images for design reference
import btnGroupAll from '../../../../assets/images/button-group/btn-group-all.png';
import btnGroupIconAll from '../../../../assets/images/button-group/btn-group-icon-all.png';

// ── Lookup map: [status][side] → imported image ──
const BTN_GROUP_IMAGE_MAP: Record<string, Record<string, typeof btnGroupBase>> = {
  default: {
    left: btnGroupDefaultLeft,
    center: btnGroupDefaultCenter,
    right: btnGroupDefaultRight,
  },
  hover: {
    left: btnGroupHoverLeft,
    center: btnGroupHoverCenter,
    right: btnGroupHoverRight,
  },
  active: {
    left: btnGroupActiveLeft,
    center: btnGroupActiveCenter,
    right: btnGroupActiveRight,
  },
  focus: {
    left: btnGroupFocusLeft,
    center: btnGroupFocusCenter,
    right: btnGroupFocusRight,
  },
  disabled: {
    left: btnGroupDisabledLeft,
    center: btnGroupDisabledCenter,
    right: btnGroupDisabledRight,
  },
};

const BTN_GROUP_STATUSES = ['default', 'hover', 'active', 'focus', 'disabled'] as const;
const BTN_GROUP_SIDES = ['left', 'center', 'right'] as const;

// Map for preview images - Button Group Counts
const PREVIEW_IMAGES = [
  { key: '1', label: 'Group 1', src: btnGroup1 },
  { key: '2', label: 'Group 2', src: btnGroup2 },
  { key: '3', label: 'Group 3', src: btnGroup3 },
  { key: '4', label: 'Group 4', src: btnGroup4 },
];

// Get the corresponding image for a status and side
function getButtonGroupImage(status: string, side: string) {
  const statusMap = BTN_GROUP_IMAGE_MAP[status];
  if (!statusMap) return null;
  return statusMap[side] || statusMap.center || null;
}

// Get the size class for the image with consistent sizing
function getSizeClass(size: string) {
  switch (size) {
    case 'l':
      return 'w-[280px] h-auto';
    case 'm':
      return 'w-[220px] h-auto';
    case 's':
      return 'w-[160px] h-auto';
    default:
      return 'w-[220px] h-auto';
  }
}

/* ============================================================
   LIVE DEMO — Now using images instead of styled button tags
============================================================ */
export function ButtonGroupDemo() {
  const [status, setStatus] = useState<'default' | 'hover' | 'active' | 'focus' | 'disabled'>('default');
  const [side, setSide] = useState<'left' | 'center' | 'right'>('center');
  const [size, setSize] = useState<'s' | 'm' | 'l'>('m');
  const [previewImage, setPreviewImage] = useState<string | null>(null); // null means show status/side image

  // Get the selected preview image
  const selectedPreview = previewImage ? PREVIEW_IMAGES.find(img => img.key === previewImage) : null;
  
  // Determine which image to show
  let currentImage;
  if (selectedPreview) {
    // If a group count is selected, show that image
    currentImage = selectedPreview.src;
  } else {
    // Otherwise show the status/side image
    currentImage = getButtonGroupImage(status, side);
  }
  
  const sizeClass = getSizeClass(size);

  // Handle status click - clear preview image selection
  const handleStatusClick = (st: typeof status) => {
    setStatus(st);
    setPreviewImage(null); // Clear group count selection
  };

  // Handle side click - clear preview image selection
  const handleSideClick = (sd: typeof side) => {
    setSide(sd);
    setPreviewImage(null); // Clear group count selection
  };

  // Handle size click - clear preview image selection
  const handleSizeClick = (s: typeof size) => {
    setSize(s);
    setPreviewImage(null); // Clear group count selection
  };

  // Handle group count click
  const handleGroupCountClick = (key: string) => {
    setPreviewImage(key);
  };

  return (
    <>
      <div
        className="p-8 flex items-center justify-center min-h-[220px]"
        style={{
          background:
            'repeating-linear-gradient(0deg, rgba(10,103,232,0.03) 0 1px, transparent 1px 24px), repeating-linear-gradient(90deg, rgba(10,103,232,0.03) 0 1px, transparent 1px 24px)',
        }}
      >
        <div className="flex flex-col items-center gap-3">
          <div className="flex items-center justify-center min-h-[120px]">
            {currentImage ? (
              <Image
                src={currentImage}
                alt={`button group ${status} ${side}`}
                className={`h-auto ${sizeClass} object-contain`}
                priority={false}
              />
            ) : (
              <div className="text-gray-400">No image available</div>
            )}
          </div>
          <span className="text-xs font-mono" style={{ color: '#8089A0' }}>
            {selectedPreview 
              ? `Group ${previewImage}` 
              : `${status.charAt(0).toUpperCase() + status.slice(1)} • ${side.charAt(0).toUpperCase() + side.slice(1)} • ${size.toUpperCase()}`
            }
          </span>
        </div>
      </div>

      <div className="p-5 border-t space-y-4" style={{ borderColor: '#EFEDE8' }}>
        <div>
          <div className="text-[10px] font-bold uppercase tracking-widest mb-2" style={{ color: '#8089A0' }}>Status</div>
          <div className="flex flex-wrap gap-2">
            {BTN_GROUP_STATUSES.map((st) => (
              <PropChip key={st} active={status === st && !selectedPreview} onClick={() => handleStatusClick(st)}>
                {st.charAt(0).toUpperCase() + st.slice(1)}
              </PropChip>
            ))}
          </div>
        </div>
        <div>
          <div className="text-[10px] font-bold uppercase tracking-widest mb-2" style={{ color: '#8089A0' }}>Side</div>
          <div className="flex gap-2">
            {BTN_GROUP_SIDES.map((sd) => (
              <PropChip key={sd} active={side === sd && !selectedPreview} onClick={() => handleSideClick(sd)}>
                {sd.charAt(0).toUpperCase() + sd.slice(1)}
              </PropChip>
            ))}
          </div>
        </div>
        <div>
          <div className="text-[10px] font-bold uppercase tracking-widest mb-2" style={{ color: '#8089A0' }}>Size</div>
          <div className="flex gap-2">
            {(['s', 'm', 'l'] as const).map((s) => (
              <PropChip key={s} active={size === s && !selectedPreview} onClick={() => handleSizeClick(s)}>
                {s.toUpperCase()}
              </PropChip>
            ))}
          </div>
        </div>
        <div>
          <div className="text-[10px] font-bold uppercase tracking-widest mb-2" style={{ color: '#8089A0' }}>Button Group Count</div>
          <div className="flex gap-2">
            {PREVIEW_IMAGES.map((img) => (
              <PropChip 
                key={img.key} 
                active={previewImage === img.key} 
                onClick={() => handleGroupCountClick(img.key)}
              >
                {img.label}
              </PropChip>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}

/* ============================================================
   SPEC SHEET — Design Reference (60% width)
   Now using combined images: btn-group-all.png and btn-group-icon-all.png
============================================================ */
export function ButtonGroupSpec() {
  return (
    <div className="p-6 overflow-y-auto max-h-[600px]">
      <SpecBadge label="Button Group" />

      {/* Button Group All - Combined image */}
      <SpecBlock title="Button Group — All States">
        <div className="flex flex-col items-center gap-3">
          <div className="w-full flex justify-center">
            <Image
              src={btnGroupAll}
              alt="Button group all states"
              className="w-full max-w-[500px] h-auto object-contain"
              priority={false}
            />
          </div>
          <span className="text-xs font-mono text-center" style={{ color: '#8089A0' }}>
            All button group states and sides
          </span>
        </div>
      </SpecBlock>

      {/* Button Group Icon All - Combined image with icons */}
      <SpecBlock title="Button Group — Icon Variants">
        <div className="flex flex-col items-center gap-3">
          <div className="w-full flex justify-center">
            <Image
              src={btnGroupIconAll}
              alt="Button group icon variants"
              className="w-4/5 max-w-[400px] h-auto object-contain"
              priority={false}
            />
          </div>
          <span className="text-xs font-mono text-center" style={{ color: '#8089A0' }}>
            Button group with icons
          </span>
        </div>
      </SpecBlock>
    </div>
  );
}