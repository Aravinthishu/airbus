'use client';
import React, { useState } from 'react';
import { PropChip, SpecBadge, SpecBlock } from '../ui-helpers';

export function ButtonGroupDemo() {
  const [count, setCount] = useState<'2' | '3' | '4' | 'overflow'>('3');
  const [size, setSize] = useState<'s' | 'm' | 'l'>('m');
  const [selected, setSelected] = useState(0);
  const sizeMap: Record<string, string> = { s: 'px-3.5 py-2 text-xs', m: 'px-5 py-2.5 text-xs', l: 'px-6 py-3.5 text-sm' };
  const labels = ['Filter A', 'Filter B', 'Filter C', 'Filter D'];
  const n = count === 'overflow' ? 4 : parseInt(count, 10);
  return (
    <>
      <div className="p-10 flex items-center justify-center min-h-[220px]">
        <div className="inline-flex rounded-xl overflow-hidden border" style={{ borderColor: '#D8D4CC' }}>
          {Array.from({ length: n }).map((_, i) => (
            <button
              key={i}
              onClick={() => setSelected(i)}
              className={`${sizeMap[size]} font-semibold border-r last:border-r-0 transition-colors`}
              style={{
                borderColor: '#D8D4CC',
                background: selected === i ? '#0a67e8' : '#FFFFFF',
                color: selected === i ? '#fff' : '#6B6B6B',
                fontFamily: "'DM Sans', sans-serif",
              }}
            >
              {labels[i]}
            </button>
          ))}
          {count === 'overflow' && (
            <div className={`${sizeMap[size]} font-semibold flex items-center`} style={{ color: '#8089A0', fontFamily: "'DM Sans', sans-serif" }}>+2</div>
          )}
        </div>
      </div>
      <div className="p-5 border-t space-y-4" style={{ borderColor: '#EFEDE8' }}>
        <div>
          <div className="text-[10px] font-bold uppercase tracking-widest mb-2" style={{ color: '#8089A0' }}>Item Count</div>
          <div className="flex gap-2">
            {(['2', '3', '4', 'overflow'] as const).map((c) => (
              <PropChip key={c} active={count === c} onClick={() => setCount(c)}>{c === 'overflow' ? 'Overflow' : c}</PropChip>
            ))}
          </div>
        </div>
        <div>
          <div className="text-[10px] font-bold uppercase tracking-widest mb-2" style={{ color: '#8089A0' }}>Size</div>
          <div className="flex gap-2">
            {(['s', 'm', 'l'] as const).map((s) => (
              <PropChip key={s} active={size === s} onClick={() => setSize(s)}>{s.toUpperCase()}</PropChip>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}

export function ButtonGroupSpec() {
  return (
    <div className="p-6">
      <SpecBadge label="Button Group" />
      <SpecBlock title="Sizes — 3 items">
        <div className="flex flex-wrap items-center gap-6">
          {(['l', 'm', 's'] as const).map((sz) => (
            <div key={sz} className="flex flex-col items-center gap-2">
              <div className="inline-flex rounded-xl overflow-hidden border" style={{ borderColor: '#D8D4CC' }}>
                {['A', 'B', 'C'].map((l, i) => (
                  <div key={l} className={`${sz === 'l' ? 'px-5 py-3 text-sm' : sz === 'm' ? 'px-4 py-2.5 text-xs' : 'px-3 py-1.5 text-[11px]'} font-semibold border-r last:border-r-0`} style={{ borderColor: '#D8D4CC', background: i === 0 ? '#0a67e8' : '#fff', color: i === 0 ? '#fff' : '#6B6B6B', fontFamily: "'DM Sans', sans-serif" }}>{l}</div>
                ))}
              </div>
              <span className="text-[9px] font-mono" style={{ color: '#8089A0' }}>{sz.toUpperCase()}</span>
            </div>
          ))}
        </div>
      </SpecBlock>
      <SpecBlock title="4 items, with overflow">
        <div className="inline-flex rounded-xl overflow-hidden border" style={{ borderColor: '#D8D4CC' }}>
          {['A', 'B', 'C', 'D'].map((l, i) => (
            <div key={l} className="px-4 py-2.5 text-xs font-semibold border-r last:border-r-0" style={{ borderColor: '#D8D4CC', background: i === 0 ? '#0a67e8' : '#fff', color: i === 0 ? '#fff' : '#6B6B6B', fontFamily: "'DM Sans', sans-serif" }}>{l}</div>
          ))}
        </div>
        <div className="mt-2 inline-block px-3 py-1.5 text-xs font-semibold rounded-lg" style={{ color: '#8089A0', background: '#EBF8FF', fontFamily: "'DM Sans', sans-serif" }}>+2</div>
      </SpecBlock>
    </div>
  );
}
