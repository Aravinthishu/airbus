'use client';
import React, { useState } from 'react';
import { PropChip, SpecBadge, SpecBlock, SpecState } from '../ui-helpers';

export function DatePickerDemo() {
  const [size, setSize] = useState<'s' | 'm' | 'l'>('m');
  const [open, setOpen] = useState(false);
  const [selected, setSelected] = useState<number | null>(null);
  const sizeMap: Record<string, string> = { s: 'px-3.5 py-2 text-xs', m: 'px-4 py-2.5 text-sm', l: 'px-4.5 py-3 text-sm' };
  const days = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];
  const leadDays = [26, 27, 28, 29, 30];
  return (
    <>
      <div className="p-10 flex items-start justify-center min-h-[220px]">
        <div className="flex flex-col gap-1.5 w-64">
          <label className="text-xs font-semibold" style={{ color: '#6B6B6B', fontFamily: "'DM Sans', sans-serif" }}>Departure date</label>
          <div
            onClick={() => setOpen((o) => !o)}
            className={`flex items-center justify-between rounded-xl border cursor-pointer ${sizeMap[size]}`}
            style={{ borderColor: '#D8D4CC', background: '#fff' }}
          >
            <span style={{ color: selected ? '#151A24' : '#8089A0', fontFamily: "'DM Sans', sans-serif" }}>
              {selected ? `2024/12/${String(selected).padStart(2, '0')}` : 'yyyy/mm/dd'}
            </span>
            <span style={{ color: '#8089A0' }}>📅</span>
          </div>
          {open && (
            <div className="rounded-xl border p-3.5 mt-1 shadow-lg bg-white" style={{ borderColor: '#D8D4CC' }}>
              <div className="flex items-center justify-between mb-2.5 text-xs font-semibold" style={{ color: '#151A24', fontFamily: "'DM Sans', sans-serif" }}>
                <span className="cursor-pointer" style={{ color: '#8089A0' }}>‹</span>
                <span>December 2024</span>
                <span className="cursor-pointer" style={{ color: '#8089A0' }}>›</span>
              </div>
              <div className="grid grid-cols-7 gap-1 text-center">
                {days.map((d) => (
                  <div key={d} className="text-[9px]" style={{ color: '#8089A0', fontFamily: "'DM Sans', sans-serif" }}>{d}</div>
                ))}
                {leadDays.map((d) => (
                  <div key={`lead-${d}`} className="text-xs py-1 rounded" style={{ color: '#C8C4BC', fontFamily: "'DM Sans', sans-serif" }}>{d}</div>
                ))}
                {Array.from({ length: 29 }).map((_, i) => {
                  const d = i + 1;
                  return (
                    <div
                      key={d}
                      onClick={() => { setSelected(d); setOpen(false); }}
                      className="text-xs py-1 rounded cursor-pointer"
                      style={{ background: selected === d ? '#0a67e8' : 'transparent', color: selected === d ? '#fff' : '#151A24', fontFamily: "'DM Sans', sans-serif" }}
                    >
                      {d}
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
      <div className="p-5 border-t space-y-3" style={{ borderColor: '#EFEDE8' }}>
        <div>
          <div className="text-[10px] font-bold uppercase tracking-widest mb-2" style={{ color: '#8089A0' }}>Size</div>
          <div className="flex gap-2">
            {(['s', 'm', 'l'] as const).map((s) => (
              <PropChip key={s} active={size === s} onClick={() => setSize(s)}>{s.toUpperCase()}</PropChip>
            ))}
          </div>
        </div>
        <p className="text-xs" style={{ color: '#8089A0' }}>Click the field to open the calendar.</p>
      </div>
    </>
  );
}

export function DatePickerSpec() {
  return (
    <div className="p-6">
      <SpecBadge label="Date & Time Picker" />
      <SpecBlock title="States">
        <div className="flex flex-wrap gap-4">
          {[
            { label: 'Default', border: '#D8D4CC', value: '' },
            { label: 'Focus', border: '#0a67e8', value: '' },
            { label: 'Filled', border: '#D8D4CC', value: '2024/12/17' },
            { label: 'Error', border: '#B00020', value: '2024/13/40' },
          ].map((s) => (
            <SpecState key={s.label} label={s.label}>
              <div className="rounded-xl border px-3.5 py-2.5 text-xs w-36 flex items-center justify-between" style={{ borderColor: s.border, color: s.value ? '#151A24' : '#8089A0', fontFamily: "'DM Sans', sans-serif" }}>
                <span>{s.value || 'yyyy/mm/dd'}</span><span>📅</span>
              </div>
            </SpecState>
          ))}
        </div>
      </SpecBlock>
    </div>
  );
}
