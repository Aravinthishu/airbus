'use client';
import React, { useState } from 'react';
import { PropChip, SpecBadge, SpecBlock, SpecState } from '../ui-helpers';

export function TextAreaDemo() {
  const [state, setState] = useState<'default' | 'error' | 'warning' | 'success' | 'disabled'>('default');
  const [size, setSize] = useState<'s' | 'm' | 'l'>('m');
  const [value, setValue] = useState('');
  const heightMap: Record<string, string> = { s: 'h-20', m: 'h-28', l: 'h-36' };
  const borderColor = state === 'error' ? '#B00020' : state === 'warning' ? '#DDAB17' : state === 'success' ? '#0a7a50' : '#D8D4CC';
  const helpText: Record<string, string> = {
    default: 'Optional — up to 240 characters.', error: 'Please add a little more detail.', warning: 'You are close to the limit.', success: 'Thanks — that is helpful.', disabled: 'This field is currently locked.',
  };
  return (
    <>
      <div className="p-10 flex items-center justify-center min-h-[220px]">
        <div className="flex flex-col gap-1.5 w-80">
          <label className="text-xs font-semibold" style={{ color: '#6B6B6B', fontFamily: "'DM Sans', sans-serif" }}>Feedback</label>
          <textarea
            value={value}
            onChange={(e) => setValue(e.target.value)}
            disabled={state === 'disabled'}
            placeholder="Tell us what could be better…"
            className={`rounded-xl border px-4 py-3 text-sm outline-none resize-none ${heightMap[size]}`}
            style={{ borderColor, background: state === 'disabled' ? '#EBF8FF' : '#fff', color: '#151A24', fontFamily: "'DM Sans', sans-serif" }}
          />
          <div className="flex justify-between text-xs" style={{ color: state === 'error' ? '#B00020' : state === 'warning' ? '#8C5E08' : '#8089A0', fontFamily: "'DM Sans', sans-serif" }}>
            <span>{helpText[state]}</span>
            <span className="font-mono">{value.length}/240</span>
          </div>
        </div>
      </div>
      <div className="p-5 border-t space-y-4" style={{ borderColor: '#EFEDE8' }}>
        <div>
          <div className="text-[10px] font-bold uppercase tracking-widest mb-2" style={{ color: '#8089A0' }}>State</div>
          <div className="flex flex-wrap gap-2">
            {(['default', 'error', 'warning', 'success', 'disabled'] as const).map((s) => (
              <PropChip key={s} active={state === s} onClick={() => setState(s)}>{s[0].toUpperCase() + s.slice(1)}</PropChip>
            ))}
          </div>
        </div>
        <div>
          <div className="text-[10px] font-bold uppercase tracking-widest mb-2" style={{ color: '#8089A0' }}>Size</div>
          <div className="flex gap-2">
            {(['s', 'm', 'l'] as const).map((s) => (
              <PropChip key={s} active={size === s} onClick={() => setSize(s)}>{s.toUpperCase()}</PropChip>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}

export function TextAreaSpec() {
  return (
    <div className="p-6">
      <SpecBadge label="Text Area" />
      <SpecBlock title="States">
        <div className="flex flex-wrap gap-4">
          {[
            { label: 'Default', border: '#D8D4CC', text: '' },
            { label: 'Focus', border: '#0a67e8', text: '' },
            { label: 'Error', border: '#B00020', text: 'Too short' },
            { label: 'Disabled', border: '#D8D4CC', text: 'Locked', disabled: true },
          ].map((s) => (
            <SpecState key={s.label} label={s.label}>
              <div className="rounded-xl border w-40 h-16 px-3 py-2 text-xs" style={{ borderColor: s.border, background: s.disabled ? '#EBF8FF' : '#fff', opacity: s.disabled ? 0.6 : 1, color: '#8089A0', fontFamily: "'DM Sans', sans-serif" }}>{s.text}</div>
            </SpecState>
          ))}
        </div>
      </SpecBlock>
    </div>
  );
}
