'use client';
import React, { useState } from 'react';
import { PropChip, SpecBadge, SpecBlock, SpecState } from '../ui-helpers';

export function InputFieldDemo() {
  const [appearance, setAppearance] = useState<'default' | 'error' | 'warning' | 'success' | 'disabled'>('default');
  const [size, setSize] = useState<'xs' | 's' | 'm' | 'l' | 'xl'>('m');
  const [prefix, setPrefix] = useState<'none' | 'icon' | 'text'>('none');
  const [suffix, setSuffix] = useState<'none' | 'icon' | 'clear'>('none');
  const sizeMap: Record<string, string> = { xs: 'px-3 py-1.5 text-xs', s: 'px-3.5 py-2 text-xs', m: 'px-4 py-2.5 text-sm', l: 'px-4.5 py-3 text-sm', xl: 'px-5 py-4 text-base' };
  const helpText: Record<string, string> = {
    default: 'Use your company email address.', error: 'Enter a valid email address.', warning: 'This email domain is unverified.', success: 'Email verified successfully.', disabled: 'This field is currently locked.',
  };
  const borderColor = appearance === 'error' ? '#B00020' : appearance === 'warning' ? '#DDAB17' : appearance === 'success' ? '#0a7a50' : '#D8D4CC';
  const helpColor = appearance === 'error' ? '#B00020' : appearance === 'warning' ? '#8C5E08' : '#8089A0';
  return (
    <>
      <div className="p-10 flex items-center justify-center min-h-[220px]">
        <div className="flex flex-col gap-1.5 w-72">
          <label className="text-xs font-semibold" style={{ color: '#6B6B6B', fontFamily: "'DM Sans', sans-serif" }}>Email address</label>
          <div className={`flex items-center gap-2 rounded-xl border ${sizeMap[size]}`} style={{ borderColor, background: appearance === 'disabled' ? '#EBF8FF' : '#fff', opacity: appearance === 'disabled' ? 0.6 : 1 }}>
            {prefix !== 'none' && <span className="font-mono" style={{ color: '#8089A0' }}>{prefix === 'icon' ? '@' : 'https://'}</span>}
            <input
              disabled={appearance === 'disabled'}
              placeholder="you@company.com"
              className="flex-1 outline-none bg-transparent"
              style={{ color: '#151A24', fontFamily: "'DM Sans', sans-serif" }}
            />
            {suffix !== 'none' && <span className="font-mono" style={{ color: '#8089A0' }}>{suffix === 'clear' ? '✕' : '✓'}</span>}
          </div>
          <p className="text-xs" style={{ color: helpColor, fontFamily: "'DM Sans', sans-serif" }}>{helpText[appearance]}</p>
        </div>
      </div>
      <div className="p-5 border-t space-y-4" style={{ borderColor: '#EFEDE8' }}>
        <div>
          <div className="text-[10px] font-bold uppercase tracking-widest mb-2" style={{ color: '#8089A0' }}>Appearance</div>
          <div className="flex flex-wrap gap-2">
            {(['default', 'error', 'warning', 'success', 'disabled'] as const).map((a) => (
              <PropChip key={a} active={appearance === a} onClick={() => setAppearance(a)}>{a[0].toUpperCase() + a.slice(1)}</PropChip>
            ))}
          </div>
        </div>
        <div>
          <div className="text-[10px] font-bold uppercase tracking-widest mb-2" style={{ color: '#8089A0' }}>Size</div>
          <div className="flex flex-wrap gap-2">
            {(['xs', 's', 'm', 'l', 'xl'] as const).map((s) => (
              <PropChip key={s} active={size === s} onClick={() => setSize(s)}>{s.toUpperCase()}</PropChip>
            ))}
          </div>
        </div>
        <div>
          <div className="text-[10px] font-bold uppercase tracking-widest mb-2" style={{ color: '#8089A0' }}>Prefix</div>
          <div className="flex gap-2">
            {(['none', 'icon', 'text'] as const).map((p) => (
              <PropChip key={p} active={prefix === p} onClick={() => setPrefix(p)}>{p === 'none' ? 'None' : p === 'icon' ? '@' : 'https://'}</PropChip>
            ))}
          </div>
        </div>
        <div>
          <div className="text-[10px] font-bold uppercase tracking-widest mb-2" style={{ color: '#8089A0' }}>Suffix</div>
          <div className="flex gap-2">
            {(['none', 'icon', 'clear'] as const).map((s) => (
              <PropChip key={s} active={suffix === s} onClick={() => setSuffix(s)}>{s === 'none' ? 'None' : s === 'icon' ? '✓' : '✕'}</PropChip>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}

export function InputFieldSpec() {
  const states: { label: string; border: string; value?: string; disabled?: boolean }[] = [
    { label: 'Default', border: '#D8D4CC' },
    { label: 'Focus', border: '#0a67e8' },
    { label: 'Error', border: '#B00020', value: 'wrong@' },
    { label: 'Success', border: '#0a7a50', value: 'ok@company.com' },
    { label: 'Disabled', border: '#D8D4CC', disabled: true },
  ];
  return (
    <div className="p-6">
      <SpecBadge label="Input Field" />
      <SpecBlock title="States">
        <div className="flex flex-wrap gap-4">
          {states.map((s) => (
            <SpecState key={s.label} label={s.label}>
              <div className="rounded-xl border px-3.5 py-2.5 text-xs w-40" style={{ borderColor: s.border, background: s.disabled ? '#EBF8FF' : '#fff', opacity: s.disabled ? 0.6 : 1, color: s.value ? '#151A24' : '#8089A0', fontFamily: "'DM Sans', sans-serif" }}>
                {s.value || 'you@company.com'}
              </div>
            </SpecState>
          ))}
        </div>
      </SpecBlock>
      <SpecBlock title="Sizes">
        <div className="flex flex-wrap items-center gap-5">
          {(['xl', 'm', 'xs'] as const).map((sz) => (
            <div key={sz} className="flex flex-col items-center gap-2">
              <div className={`rounded-xl border w-40 ${sz === 'xl' ? 'px-5 py-4 text-base' : sz === 'm' ? 'px-4 py-2.5 text-sm' : 'px-3 py-1.5 text-xs'}`} style={{ borderColor: '#D8D4CC', color: '#8089A0', fontFamily: "'DM Sans', sans-serif" }}>Label</div>
              <span className="text-[9px] font-mono" style={{ color: '#8089A0' }}>{sz.toUpperCase()}</span>
            </div>
          ))}
        </div>
      </SpecBlock>
    </div>
  );
}
