'use client';
import React, { useState } from 'react';
import { PropChip, SpecBadge, SpecBlock, SpecState } from '../ui-helpers';

export function CheckboxDemo() {
  const [size, setSize] = useState<'m' | 'l'>('m');
  const [rows, setRows] = useState<{ label: string; state: 'unchecked' | 'checked' | 'indeterminate' }[]>([
    { label: 'Notify me by email', state: 'unchecked' },
    { label: 'Remember this device', state: 'checked' },
    { label: 'Select all permissions', state: 'indeterminate' },
  ]);
  const dim = size === 'l' ? 28 : 22;
  const toggle = (i: number) => {
    setRows((r) => r.map((row, idx) => (idx === i ? { ...row, state: row.state === 'unchecked' ? 'checked' : 'unchecked' } : row)));
  };
  return (
    <>
      <div className="p-10 flex items-center justify-center min-h-[220px]">
        <div className="flex flex-col gap-1">
          {rows.map((row, i) => (
            <div key={row.label} onClick={() => toggle(i)} className="flex items-center gap-3 py-2.5 cursor-pointer">
              <div
                className="rounded-md flex items-center justify-center flex-shrink-0 transition-colors"
                style={{
                  width: dim, height: dim, borderRadius: size === 'l' ? 8 : 6,
                  border: row.state === 'unchecked' ? '2px solid #D8D4CC' : 'none',
                  background: row.state === 'unchecked' ? 'transparent' : '#0a67e8',
                  color: '#fff', fontSize: size === 'l' ? 14 : 12,
                }}
              >
                {row.state === 'checked' ? '✓' : row.state === 'indeterminate' ? '–' : ''}
              </div>
              <span className="text-sm" style={{ color: '#151A24', fontFamily: "'DM Sans', sans-serif" }}>{row.label}</span>
            </div>
          ))}
        </div>
      </div>
      <div className="p-5 border-t space-y-3" style={{ borderColor: '#EFEDE8' }}>
        <div>
          <div className="text-[10px] font-bold uppercase tracking-widest mb-2" style={{ color: '#8089A0' }}>Size</div>
          <div className="flex gap-2">
            {(['m', 'l'] as const).map((s) => (
              <PropChip key={s} active={size === s} onClick={() => setSize(s)}>{s.toUpperCase()}</PropChip>
            ))}
          </div>
        </div>
        <p className="text-xs" style={{ color: '#8089A0' }}>Click any row to toggle its state.</p>
      </div>
    </>
  );
}

export function CheckboxSpec() {
  return (
    <div className="p-6">
      <SpecBadge label="Checkbox" />
      <SpecBlock title="States">
        <div className="flex flex-wrap gap-5">
          <SpecState label="Unselected"><div className="w-6 h-6 rounded-md" style={{ border: '2px solid #D8D4CC' }} /></SpecState>
          <SpecState label="Selected"><div className="w-6 h-6 rounded-md flex items-center justify-center text-white text-xs" style={{ background: '#0a67e8', fontFamily: "'DM Sans', sans-serif" }}>✓</div></SpecState>
          <SpecState label="Indeterminate"><div className="w-6 h-6 rounded-md flex items-center justify-center text-white text-xs" style={{ background: '#0a67e8', fontFamily: "'DM Sans', sans-serif" }}>–</div></SpecState>
          <SpecState label="Focus"><div className="w-6 h-6 rounded-md flex items-center justify-center text-white text-xs" style={{ background: '#0a67e8', boxShadow: '0 0 0 3px rgba(10,103,232,0.25)', fontFamily: "'DM Sans', sans-serif" }}>✓</div></SpecState>
          <SpecState label="Disabled"><div className="w-6 h-6 rounded-md flex items-center justify-center text-white text-xs" style={{ background: '#0a67e8', opacity: 0.4, fontFamily: "'DM Sans', sans-serif" }}>✓</div></SpecState>
        </div>
      </SpecBlock>
      <SpecBlock title="Sizes">
        <div className="flex items-center gap-6">
          <SpecState label="L"><div className="w-7 h-7 rounded-lg flex items-center justify-center text-white text-sm" style={{ background: '#0a67e8', fontFamily: "'DM Sans', sans-serif" }}>✓</div></SpecState>
          <SpecState label="M"><div className="w-[22px] h-[22px] rounded-md flex items-center justify-center text-white text-xs" style={{ background: '#0a67e8', fontFamily: "'DM Sans', sans-serif" }}>✓</div></SpecState>
        </div>
      </SpecBlock>
    </div>
  );
}
