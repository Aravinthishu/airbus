'use client';
import React, { useState } from 'react';
import { PropChip, SpecBadge, SpecBlock, SpecState } from '../ui-helpers';

export function FabDemo() {
  const [size, setSize] = useState<'s' | 'l'>('l');
  const [open, setOpen] = useState(false);
  const main = size === 'l' ? 60 : 44;
  const mini = size === 'l' ? 44 : 36;
  return (
    <>
      <div className="p-10 flex items-end justify-center min-h-[220px]">
        <div className="relative flex flex-col items-center gap-3" style={{ height: 200 }}>
          {['🔗', '✉', '🖨'].map((icon, i) => (
            <div
              key={icon}
              className="rounded-full border flex items-center justify-center shadow-md transition-all"
              style={{
                width: mini, height: mini, borderColor: '#D8D4CC', background: '#fff', color: '#0a67e8',
                opacity: open ? 1 : 0, transform: open ? 'translateY(0)' : 'translateY(10px)', transitionDelay: `${i * 40}ms`,
              }}
            >
              {icon}
            </div>
          ))}
          <button
            onClick={() => setOpen((o) => !o)}
            className="rounded-full flex items-center justify-center text-white shadow-lg transition-transform"
            style={{ width: main, height: main, background: '#0a67e8', fontSize: main * 0.4, fontFamily: "'DM Sans', sans-serif" }}
          >
            {open ? '×' : '+'}
          </button>
        </div>
      </div>
      <div className="p-5 border-t space-y-3" style={{ borderColor: '#EFEDE8' }}>
        <div>
          <div className="text-[10px] font-bold uppercase tracking-widest mb-2" style={{ color: '#8089A0' }}>Size</div>
          <div className="flex gap-2">
            {(['s', 'l'] as const).map((s) => (
              <PropChip key={s} active={size === s} onClick={() => setSize(s)}>{s.toUpperCase()}</PropChip>
            ))}
          </div>
        </div>
        <p className="text-xs" style={{ color: '#8089A0' }}>Click the button to expand the speed-dial.</p>
      </div>
    </>
  );
}

export function FabSpec() {
  return (
    <div className="p-6">
      <SpecBadge label="Float Action Button" />
      <SpecBlock title="States — Size L">
        <div className="flex flex-wrap gap-5">
          <SpecState label="Default"><div className="w-14 h-14 rounded-full flex items-center justify-center text-white text-xl shadow-lg" style={{ background: '#0a67e8', fontFamily: "'DM Sans', sans-serif" }}>+</div></SpecState>
          <SpecState label="Hover"><div className="w-14 h-14 rounded-full flex items-center justify-center text-white text-xl shadow-lg" style={{ background: '#0850BA', fontFamily: "'DM Sans', sans-serif" }}>+</div></SpecState>
          <SpecState label="Active"><div className="w-14 h-14 rounded-full flex items-center justify-center text-white text-xl shadow-lg" style={{ background: '#063E8F', transform: 'scale(.94)', fontFamily: "'DM Sans', sans-serif" }}>×</div></SpecState>
          <SpecState label="Focus"><div className="w-14 h-14 rounded-full flex items-center justify-center text-white text-xl shadow-lg" style={{ background: '#0a67e8', boxShadow: '0 0 0 4px rgba(10,103,232,0.25)', fontFamily: "'DM Sans', sans-serif" }}>+</div></SpecState>
          <SpecState label="Disabled"><div className="w-14 h-14 rounded-full flex items-center justify-center text-white text-xl shadow-lg" style={{ background: '#0a67e8', opacity: 0.4, fontFamily: "'DM Sans', sans-serif" }}>+</div></SpecState>
        </div>
      </SpecBlock>
      <SpecBlock title="Sizes">
        <div className="flex items-end gap-6">
          <SpecState label="L"><div className="w-16 h-16 rounded-full flex items-center justify-center text-white text-2xl shadow-lg" style={{ background: '#0a67e8', fontFamily: "'DM Sans', sans-serif" }}>+</div></SpecState>
          <SpecState label="S"><div className="w-11 h-11 rounded-full flex items-center justify-center text-white text-lg shadow-lg" style={{ background: '#0a67e8', fontFamily: "'DM Sans', sans-serif" }}>+</div></SpecState>
        </div>
      </SpecBlock>
    </div>
  );
}
