'use client';
import React, { useState } from 'react';
import { PropChip, SpecBadge, SpecBlock, SpecState } from '../ui-helpers';

export const BTN_VARIANTS: { key: string; label: string; cls: string }[] = [
  { key: 'primary', label: 'Primary', cls: '' },
  { key: 'secondary', label: 'Secondary', cls: '' },
  { key: 'ghost', label: 'Ghost', cls: '' },
  { key: 'ghostneg', label: 'Ghost Negative', cls: '' },
  { key: 'success', label: 'Success', cls: '' },
  { key: 'warning', label: 'Warning', cls: '' },
  { key: 'error', label: 'Error', cls: '' },
];

export const BTN_SIZE_MAP: Record<string, string> = {
  xl: 'px-8 py-4 text-base',
  l: 'px-6 py-3.5 text-sm',
  m: 'px-5 py-2.5 text-sm',
  s: 'px-4 py-2 text-xs',
  xs: 'px-3 py-1.5 text-xs',
};

export function btnVariantStyle(variant: string): React.CSSProperties {
  switch (variant) {
    case 'primary':
      return { background: '#0a67e8', color: '#fff', boxShadow: '0 6px 18px rgba(10,103,232,0.28)' };
    case 'secondary':
      return { background: 'transparent', color: '#0a67e8', border: '1.5px solid #0a67e8' };
    case 'ghost':
      return { background: 'transparent', color: '#151A24' };
    case 'ghostneg':
      return { background: '#0D0D0D', color: '#fff' };
    case 'success':
      return { background: '#0a7a50', color: '#fff' };
    case 'warning':
      return { background: '#DDAB17', color: '#3A2B00' };
    case 'error':
      return { background: '#B00020', color: '#fff' };
    default:
      return {};
  }
}

export function ButtonDemo() {
  const [variant, setVariant] = useState('primary');
  const [size, setSize] = useState('l');
  return (
    <>
      <div
        className="p-10 flex items-center justify-center min-h-[220px]"
        style={{
          background:
            'repeating-linear-gradient(0deg, rgba(10,103,232,0.03) 0 1px, transparent 1px 24px), repeating-linear-gradient(90deg, rgba(10,103,232,0.03) 0 1px, transparent 1px 24px)',
        }}
      >
        <button
          className={`rounded-xl font-semibold transition-all ${BTN_SIZE_MAP[size]}`}
          style={{ fontFamily: "'DM Sans', sans-serif", ...btnVariantStyle(variant) }}
        >
          Launch
        </button>
      </div>
      <div className="p-5 border-t" style={{ borderColor: '#EFEDE8' }}>
        <div className="mb-4">
          <div className="text-[10px] font-bold uppercase tracking-widest mb-2" style={{ color: '#8089A0' }}>Variant</div>
          <div className="flex flex-wrap gap-2">
            {BTN_VARIANTS.map((v) => (
              <PropChip key={v.key} active={variant === v.key} onClick={() => setVariant(v.key)}>{v.label}</PropChip>
            ))}
          </div>
        </div>
        <div>
          <div className="text-[10px] font-bold uppercase tracking-widest mb-2" style={{ color: '#8089A0' }}>Size</div>
          <div className="flex flex-wrap gap-2">
            {['xl', 'l', 'm', 's', 'xs'].map((s) => (
              <PropChip key={s} active={size === s} onClick={() => setSize(s)}>{s.toUpperCase()}</PropChip>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}

export function ButtonSpec() {
  return (
    <div className="p-6">
      <SpecBadge label="Button" />
      <SpecBlock title="States — Primary">
        <div className="flex flex-wrap gap-4">
          <SpecState label="Default"><button className="px-5 py-2.5 rounded-xl text-sm font-semibold" style={{ ...btnVariantStyle('primary'), fontFamily: "'DM Sans', sans-serif" }}>Launch</button></SpecState>
          <SpecState label="Hover"><button className="px-5 py-2.5 rounded-xl text-sm font-semibold" style={{ ...btnVariantStyle('primary'), background: '#0850BA', fontFamily: "'DM Sans', sans-serif" }}>Launch</button></SpecState>
          <SpecState label="Active"><button className="px-5 py-2.5 rounded-xl text-sm font-semibold" style={{ ...btnVariantStyle('primary'), background: '#063E8F', transform: 'scale(.96)', fontFamily: "'DM Sans', sans-serif" }}>Launch</button></SpecState>
          <SpecState label="Focus"><button className="px-5 py-2.5 rounded-xl text-sm font-semibold" style={{ ...btnVariantStyle('primary'), boxShadow: '0 0 0 3px rgba(10,103,232,0.25), 0 6px 18px rgba(10,103,232,0.28)', fontFamily: "'DM Sans', sans-serif" }}>Launch</button></SpecState>
          <SpecState label="Disabled"><button className="px-5 py-2.5 rounded-xl text-sm font-semibold" style={{ ...btnVariantStyle('primary'), opacity: 0.4, fontFamily: "'DM Sans', sans-serif" }}>Launch</button></SpecState>
        </div>
      </SpecBlock>
      <SpecBlock title="Variants">
        <div className="flex flex-wrap gap-2">
          {BTN_VARIANTS.map((v) => (
            <button key={v.key} className="px-4 py-2 rounded-lg text-xs font-semibold" style={{ ...btnVariantStyle(v.key), fontFamily: "'DM Sans', sans-serif" }}>{v.label}</button>
          ))}
        </div>
      </SpecBlock>
      <SpecBlock title="Sizes">
        <div className="flex flex-wrap items-center gap-5">
          {['xl', 'l', 'm', 's', 'xs'].map((s) => (
            <div key={s} className="flex flex-col items-center gap-2">
              <button className={`rounded-xl font-semibold ${BTN_SIZE_MAP[s]}`} style={{ ...btnVariantStyle('primary'), fontFamily: "'DM Sans', sans-serif" }}>Launch</button>
              <span className="text-[9px] font-mono" style={{ color: '#8089A0' }}>{s.toUpperCase()}</span>
            </div>
          ))}
        </div>
      </SpecBlock>
    </div>
  );
}
